Tyler Gemora, tgemora@uci.edu, 31672308
Khoa Nguyen, khoan8@uci.edu, 43498533

The game "Draw the Laser" has the user draw lasers on screen with the mouse to fend off robots. There are waves to get through to win the game.

Feeling:
We want the players to feel like they need to concentrate on the game in order to win.
They shouldn't feel that frustrated at the game's controls.
They should feel that the sound effects enhance the experience.

Other:
All assets are either part of the Unity Standard Asset Package or assets that we made ourselves.
We performed playtesting and used it to improve our game, but it will take time to organize all of it, so it is not included here.